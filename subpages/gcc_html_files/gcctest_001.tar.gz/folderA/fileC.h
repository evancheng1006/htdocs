int c = 3;
