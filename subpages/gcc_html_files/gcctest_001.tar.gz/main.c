#include "folderA/fileA.h"
#include "fileB.h"
#include "fileC.h"
#include "fileE.h"

//#include "www/fileD.h"

int main()
{
    return 0;
}
/* 
compile command: 
gcc main.c                          //failed
gcc -IfolderA main.c                //failed
gcc -IfolderB -I. main.c            //succeeded when there is no #include "www/fileD.h" and fileC.h is correct
gcc -IfolderA -IfolderB main.c      //succeeded
gcc -IfolderB -IfolderA main.c      //failed (because folderB/fileC.h is wrong)
gcc -IfolderA -IfolderB -I. main.c  //succeeded

files:
root: folderB, folderA, main.c, fileE.h
folderA: fileA.h www fileC.h
www: fileD.h
folderB: fileB.h fileC.h(with wrong C languange)

*/

